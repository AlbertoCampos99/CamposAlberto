package org.CamposAlberto.Tema8.EJ3;

public class PrimoException extends Exception {
	public PrimoException(String mensaje) {
			super(mensaje);
		}

	}
