package org.CamposAlberto.Tema8.EJ2;
import java.lang.Exception;

public class FechaException extends Exception {
	public FechaException(String mensaje) {
		super(mensaje);
	}

}
